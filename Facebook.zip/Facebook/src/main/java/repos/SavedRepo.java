package repos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SavedRepo 
{
	static WebElement element;
	public static WebElement createnewcol(WebDriver driver)
	{
		element= driver.findElement(By.xpath("//span[contains(text(),'Create new collection')]"));
		return element;
	}
	
	static WebElement element1;
	public static WebElement collname(WebDriver driver)
	{
		element1=driver.findElement(By.cssSelector("input[placeholder='Give your collection a name...']"));
		return element1;
	}
	
}
