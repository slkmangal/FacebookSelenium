package repos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EventsHomeRepo 
{
	static WebElement element;
	public static WebElement search(WebDriver driver)
	{
		element= driver.findElement(By.cssSelector("input[aria-label='Search events']"));
		return element;
	}
}
