package repos;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginObs 
{
	static WebElement element;
	public static WebElement un(WebDriver driver)
	{
		element=driver.findElement(By.name("email"));
		return element;
	}
	
	public static WebElement pw(WebDriver driver)
	{
		element=driver.findElement(By.name("pass"));
		return element;
	}
	
	public static WebElement submit(WebDriver driver)
	{
		element=driver.findElement(By.name("login"));
		return element;
	}
	
	public static WebElement contBtn(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		element=driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/div/div/div/form/div/button"));
		return element;
	}

}
