package facebookpkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Registration {

	public static void main(String[] args) throws IOException, InterruptedException
	{
		//System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		Thread.sleep(3000);

		driver.manage().window().maximize();
		driver.findElement(By.linkText("Create New Account")).click();


		File f=new File("E:\\shilki\\Facebook\\Data\\Crediantials.xlsx");
		FileInputStream fis=new FileInputStream(f);

		XSSFWorkbook w=new XSSFWorkbook(fis);
		XSSFSheet sh=w.getSheet("Registration");



		for(int i=1; i<13; i++)
		{
			String FN= sh.getRow(i).getCell(0).toString();
			String SN= sh.getRow(i).getCell(1).toString();
			String mobe= sh.getRow(i).getCell(2).toString();
			String pw= sh.getRow(i).getCell(3).toString();
			System.out.println(FN+ " , " +SN+ " , " +mobe+ " , " +pw);

			driver.findElement(By.name("firstname")).sendKeys(FN);
			driver.findElement(By.name("lastname")).sendKeys(SN);
			driver.findElement(By.name("reg_email__")).sendKeys(mobe);



			try
			{
				driver.findElement(By.name("reg_email_confirmation__")).sendKeys(mobe);
			}
			catch(Exception e)
			{

			}



			driver.findElement(By.name("reg_passwd__")).sendKeys(pw);

			WebElement dobd=driver.findElement(By.id("day"));
			Select dobday=new Select(dobd);
			//Thread.sleep(3000);
			dobday.selectByValue("16");
			//Thread.sleep(3000);

			WebElement dobm=driver.findElement(By.id("month"));
			Select dobmonth=new Select(dobm);
			//Thread.sleep(3000);
			dobmonth.selectByVisibleText("Aug");
			//Thread.sleep(3000);

			WebElement doby=driver.findElement(By.id("year"));
			Select dobyear=new Select(doby);
			dobyear.selectByValue("1995");
			Thread.sleep(3000);


			WebElement gender=driver.findElement(By.cssSelector("input[value='1']"));
			gender.click();
			Thread.sleep(3000);


			driver.findElement(By.name("websubmit")).click();
			Thread.sleep(3000);

			try
			{
				driver.findElement(By.name("firstname")).clear();
				driver.findElement(By.name("lastname")).clear();
				driver.findElement(By.name("reg_email__")).clear();
				try
				{
					driver.findElement(By.name("reg_email_confirmation__")).clear();
				}
				catch(Exception e)
				{

				}			

				driver.findElement(By.name("reg_passwd__")).clear();
			}
			catch(Exception e)
			{

			}


			//   /html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/label[1]/div[1]/input[1]


		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		WebElement frame1= driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/iframe"));
		driver.switchTo().frame(frame1);

		driver.findElement(By.xpath("//input[@id='code_in_cliff']")).sendKeys("1234");
		Thread.sleep(10000);

		driver.findElement(By.name("confirm")).click();
		//driver.findElement(By.linkText("Send Email Again")).click();
		//driver.findElement(By.linkText("OK")).click();
		driver.findElement(By.linkText("Update Contact Info")).click();
		driver.findElement(By.name("contactpoint")).sendKeys("abcd");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[5]/div[2]/div/div/form/div[3]/button")).click();
		//driver.switchTo().alert().dismiss();
		driver.findElement(By.xpath("/html/body/div[6]/div[2]/div/div/div/div/div[1]/div/div[2]/div/button")).click();
		driver.findElement(By.linkText("Cancel")).click();
		//Thread.sleep(3000);


		//WebDriverWait ob=new WebDriverWait(driver,Duration.ofSeconds(60));
		//ob.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/iframe")));

		//implicitlyWait(Duration.ofSeconds(30));
		//WebElement frame2= driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/iframe"));
		//driver.switchTo().frame(frame2);
		WebElement otpclear=driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div/div[1]/div[2]/form/div[1]/div[1]/label/div/input"));
		otpclear.clear();		
		otpclear.sendKeys("45203");
		Thread.sleep(3000);
		driver.findElement(By.name("confirm")).click();


		Thread.sleep(10000);

		driver.findElement(By.linkText("OK")).click();


		System.out.println("done");
		driver.close();
	}

}
