package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Watch 
{
	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		LoginMain.loginall(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.findElement(By.xpath("//span[contains(text(),'Watch')]")).click();
		System.out.println("Watch clicked");
		
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div/div/div[1]/a/div/div[2]/div/div/div/div/span/span/span")).click();
		System.out.println("Watch : Home clicked");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div/div/div[2]/a/div[1]/div[2]/div/div/div/div/span/span/span")).click();
		System.out.println("Watch : Live clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div/div/div[3]/a/div[1]/div[2]/div/div/div/div/span/span/span")).click();
		System.out.println("Watch : Shows clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div/div/div[4]/a/div[1]/div[2]/div/div/div/div/span/span/span")).click();
		System.out.println("Watch : Saved Videos clicked");
		Thread.sleep(3000);
		WebElement sv=driver.findElement(By.cssSelector("input[aria-label='Search videos']"));
		sv.sendKeys("Loard Ram");
		sv.sendKeys(Keys.ENTER);
		System.out.println("Watch : Search videos result is here");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),'Sort by')]")).click();
		System.out.println("Watch : Search Videos : Sort by clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Most recent')]")).click();
		System.out.println("Watch : search videos : Most recent selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Date posted')]")).click();
		System.out.println("Watch : search videos : Date posted clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'This week')]")).click();
		System.out.println("Watch : search videos : Date posted : This week selected");
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[aria-label='Live']")).click();
		System.out.println("Watch : search videos : Live ON");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("Selection RESET");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/watch");
		Thread.sleep(3000);
		
		driver.close();
		
	}
}
