package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import repos.SavedRepo;

public class Saved 
{
	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		LoginMain.loginall(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
		driver.findElement(By.xpath("//span[contains(text(),'Saved')]")).click();
		System.out.println("Saved clicked");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[contains(text(),'Saved items')]")).click();
		System.out.println("Saved : Saved items clicked");
		Thread.sleep(3000);
		Actions a =new Actions(driver);
		a.moveToElement(SavedRepo.createnewcol(driver)).click().build().perform();
		System.out.println("Saved : Create new collection clicked");
		Thread.sleep(5000);
		a.moveToElement(SavedRepo.collname(driver)).sendKeys("MyFirstCollection").build().perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/div[3]/div[2]/div[1]/div[2]/div/div[1]/div/span/span")).click();
		System.out.println("Saved : Create new collection clicked : Cancel clicked");
	
		a.moveToElement(SavedRepo.createnewcol(driver)).click().build().perform();
		System.out.println("Saved : Create new collection clicked");
		Thread.sleep(5000);
		a.moveToElement(SavedRepo.collname(driver)).sendKeys("MyFirstCollection").build().perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/div[2]/div/i")).click();
		System.out.println("Saved : Create new collection clicked : Cross clicked");
		
		a.moveToElement(SavedRepo.createnewcol(driver)).click().build().perform();
		System.out.println("Saved : Create new collection clicked");
		Thread.sleep(5000);
		a.moveToElement(SavedRepo.collname(driver)).sendKeys("MyFirstCollection").build().perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/div[3]/div[2]/div[2]/div[1]/div/div[1]/div/span/span")).click();
		System.out.println("Saved : Create new collection clicked : Create clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/saved/?cref=28");
		System.out.println("Back to Home");
		Thread.sleep(3000);
		
		driver.close();
	}
}
