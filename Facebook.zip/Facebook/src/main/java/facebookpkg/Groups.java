package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Groups 
{
	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		LoginMain.loginall(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.findElement(By.xpath("//span[contains(text(),'Groups')]")).click();
		System.out.println("Groups clicked");
		
		//Your feeds
		driver.findElement(By.xpath("//span[contains(text(),'Your feed')]")).click();
		System.out.println("Groups: Your Feeds clicked");
		
		//Discover
		driver.findElement(By.linkText("Discover")).click();
		System.out.println("Groups : Discover clicked");
		
/*		//Create new group
		driver.findElement(By.xpath("//span[contains(text(),'Create New Group')]")).click();
		System.out.println("Groups : Create new Group clicked");
		Thread.sleep(5000);
		WebElement gn=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[3]/div[2]/div[1]/div/div[3]/div[1]/div[2]/div/div[2]/div/div/label/div/div/input"));
		gn.sendKeys("MyFirstGroup");
		System.out.println("Groups : Create new group : Group name -> MyFirstGroup");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[3]/div[2]/div[1]/div/div[3]/div[1]/div[2]/div/div[3]/div/div/div/label/div/div[1]/div/div")).click();
		System.out.println("Groups : Create new group : Group name -> MyFirstGroup : Privacy clicked");
		driver.findElement(By.xpath("//span[contains(text(),\"Only members can see who's in the group and what t\")]")).click();
		System.out.println("Groups : Create new group : Group name -> MyFirstGroup : Privacy : choose privacy -> Private");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Visible')]")).click();
		System.out.println("Groups : Create new group : Group name -> MyFirstGroup : Privacy : choose privacy -> Private : Visible clicked");
		driver.findElement(By.xpath("//span[contains(text(),'Only members can find this group.')]")).click();
		System.out.println("Groups : Create new group : Group name -> MyFirstGroup : Privacy : choose privacy -> Private : Visible -> Hidden selected");
		Thread.sleep(3000);		
		//WebElement cg=driver.findElement(By.xpath("//div[4]/div/div/div[1]/div/div[3]/div[2]/div[1]/div/div[5]/div/div/div"));
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[3]/div[2]/div[1]/div/div[4]/div/div/div/div/div[1]"))).click().build().perform();
		System.out.println("MyFirstGroup Created Successfully");
*/		
		//Search
		WebElement sg=driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[2]/div/div/div/div/label/input"));
		sg.sendKeys("MyFirstGroup");
		sg.sendKeys(Keys.ENTER);
		System.out.println("Group Search result is here");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'All')]")).click();
		System.out.println("Group Serach : All clicked");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div/div/div[2]/div/div[2]/div/a/div[1]/div[2]/div/div/div/div/span/span")).click();
		System.out.println("Group Search : Groups clicked");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),'City')]")).click();
		System.out.println("Group Search : Groups : City clicked");
		Thread.sleep(3000);
		driver.navigate().refresh();
		Thread.sleep(10000);
		driver.findElement(By.cssSelector("input[aria-label='Public groups']")).click();
		System.out.println("Group Search : Groups : Public Groups ON");
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[aria-label='My groups']")).click();
		System.out.println("Group Search : Groups : My Groups ON");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Group posts')]")).click();
		System.out.println("Group Search : Group Posts clicked");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),'Sort by')]")).click();
		System.out.println("Group Search : Group Posts : Sort by clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[3]/div/div/div/div[2]/div/div/div[1]/div[1]/div/div/div/div/div[1]/div/div/div[1]")).click();
		System.out.println("Group Search : Group Posts : Sort by : Most Recent selected");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div/div/div[2]/div/div[3]/div[2]/div[2]/div/div[2]/div/input")).click();
		System.out.println("Group Search : Group Posts : Posts you've seen ON");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Date posted')]")).click();
		System.out.println("Group Search : Group Posts : Date Posted clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'2020')]")).click();
		System.out.println("Group Search : Group Posts : Date Posted : 2020 selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Tagged location')]")).click();
		System.out.println("Group Search : Group Posts :Tagged location clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("Selection RESET");
				
		driver.close();

	}

}
