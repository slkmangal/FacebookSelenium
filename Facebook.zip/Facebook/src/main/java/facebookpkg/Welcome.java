package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Welcome
{

	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();

		driver.findElement(By.name("email")).sendKeys("slkmangal@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("Automation@1234");
		driver.findElement(By.name("login")).click();
		JavascriptExecutor js=(JavascriptExecutor)driver;

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.xpath("//span[contains(text(),'Welcome')]")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		/*	
		driver.findElement(By.xpath("//span[contains(text(),'Add Picture')]")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		//driver.findElement(By.xpath("//span[contains(text(),'Upload Photo')]")).click();


		WebElement upload_file=driver.findElement(By.xpath("//span[contains(text(),'Upload Photo')]"));

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Actions a=new Actions(driver);

		//upload_file.click();
		//a.moveToElement(upload_file).sendKeys("E:\\shilki\\Facebook\\Data\\dp.jpg").build().perform();
		upload_file.sendKeys("E:\\shilki\\Facebook\\Data\\dp.jpg");
		System.out.println("File upload successful");
		 */


		//Find People you may know
		WebElement findp=driver.findElement(By.cssSelector("input[placeholder='Search by name']"));
		findp.sendKeys("aayesha");
		findp.sendKeys(Keys.ENTER);

		//All
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//span[contains(text(),'All')]")).click();
		System.out.println("Clicked on all");

		//posts
		driver.findElement(By.xpath("//span[contains(text(),'Posts')]")).click();
		System.out.println("Clicked on Posts");
		/*
		//sort by
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//span[contains(text(),'Sort by')]")).click();
		Thread.sleep(4000);
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		WebElement more=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[2]/div/div/div[1]/div[1]/div/div/div/div/div[1]/div/div/div[1]/div/div/span"));
		wait.until(ExpectedConditions.elementToBeClickable(more));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", more);		
		System.out.println("Most recent clicked");		
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[1]/div/div[2]/div[1]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div[2]/div/i")).click();
		System.out.println("sort by done");
		 */
		//post you have seen
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("input[aria-checked='false']")).click();
		System.out.println("ON");
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("input[aria-checked='true']")).click();
		System.out.println("OFF");
		Thread.sleep(10000);


		//Date Posted
		driver.findElement(By.xpath("//span[contains(text(),'Date posted')]")).click();
		System.out.println("date posted clicked");
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//span[contains(text(),'2018')]")).click();
		Thread.sleep(3000);
		System.out.println("2022 selected");

		//posts from
		driver.findElement(By.xpath("//span[contains(text(),'Posts from')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Your friends')]")).click();
		System.out.println("Your friends selected");
		Thread.sleep(3000);

		//tagged location
		driver.findElement(By.xpath("//span[contains(text(),'Tagged location')]")).click();
		System.out.println("tagged location clicked");
		Thread.sleep(3000);

		//Reset		
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("Reset done");
		Thread.sleep(3000);

		//People
		driver.findElement(By.xpath("//span[contains(text(),'People')]")).click();

		//People : Friends of Friends
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("input[aria-checked='false']")).click();
		System.out.println("Friends of friends ON");
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("input[aria-checked='true']")).click();
		System.out.println("Friends of friends OFF");
		Thread.sleep(10000);

		//People : city
		driver.findElement(By.xpath("//span[contains(text(),'City')]")).click();
		System.out.println("People's city clicked");
		driver.navigate().refresh();
		Thread.sleep(3000);

		//People : Education
		driver.findElement(By.xpath("//span[contains(text(),'Education')]")).click();
		System.out.println("People's Education clicked");
		driver.navigate().refresh();
		Thread.sleep(3000);

		//People : Work
		driver.findElement(By.xpath("//span[contains(text(),'Work')]")).click();
		System.out.println("People's Work clicked");
		driver.navigate().refresh();
		Thread.sleep(3000);
		System.out.println("People tab Completed");

		//Photos
		driver.findElement(By.xpath("//span[contains(text(),'Photos')]")).click();
		System.out.println("Photos Clicked");
		driver.findElement(By.xpath("//span[contains(text(),'Posted by')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Your friends and groups')]")).click();
		System.out.println("Photos : Posted by your friends and groups selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Photo type')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),\"Photos you've seen\")]")).click();
		System.out.println("photo type : Photos you have seen selected");
		driver.findElement(By.xpath("//span[contains(text(),'Tagged location')]")).click();
		System.out.println("Tagged location clicked");
		driver.navigate().refresh();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Date posted')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'2019')]")).click();
		System.out.println("Date Posted : 2019 selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("selection reset");

		//Videos
		driver.findElement(By.xpath("//span[contains(text(),'Videos')]")).click();
		System.out.println("Clicked on videos"); 
		/*	driver.findElement(By.xpath("//span[contains(text(),'Sort by')]")).click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]")).click();
		System.out.println("Videos : sort by : most recent selected"); */
		driver.findElement(By.xpath("//span[contains(text(),'Date posted')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'This week')]")).click();
		System.out.println("Videos : Date posted : This week selected");

		Thread.sleep(4000);
		driver.findElement(By.cssSelector("input[aria-checked='false']")).click();
		System.out.println("Videos : Live ON");
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("input[aria-checked='true']")).click();
		System.out.println("Videos : Live OFF");
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("selection reset");

		//Marketplace
		js.executeScript("window.scrollTo(0,document.body.scrollHeight),0");
		driver.findElement(By.xpath("//span[contains(text(),'Marketplace')]")).click();
		System.out.println("Marketplace clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/search/people/?q=aayesha");
		Thread.sleep(3000);

		//Pages
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//		driver.findElement(By.xpath("//span[contains(text(),'Pages')]")).click();

		js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//span[contains(text(),'Pages')]")));
		System.out.println("clicked on Pages");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Shops']")).click();
		System.out.println("Shops ON");
		Thread.sleep(4000);
		//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[7]/div[2]/div[1]/div[1]/div[2]/div[1]/input[1]")).click();
		//System.out.println("Shops OFF");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[contains(text(),'Location')]")).click();
		System.out.println("Pages : Location clicked");
		driver.navigate().refresh();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//span[contains(text(),'Category')]")).click();
		System.out.println("Category clicked");
		driver.findElement(By.xpath("//span[contains(text(),'Company, Organisation or Institution')]")).click();
		System.out.println("Comapny, Organisation or Insttitution selected");

		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[7]/div[2]/div[3]/div[1]/div[2]/div[1]/input[1]")).click();
		System.out.println("Verified ON");
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("selection reset");



		driver.close();
	}

}
