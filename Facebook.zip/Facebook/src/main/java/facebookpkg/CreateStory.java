package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateStory 
{
	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		LoginMain.loginall(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		Thread.sleep(4000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[2]/div[3]/div/div[1]/div[1]/ul/li[1]/span/div/a")).click();
		System.out.println("Home clicked");
		Thread.sleep(5000);
		driver.findElement(By.cssSelector("a[href='/stories/create/']")).click();
		System.out.println("Create story clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div/div/div/div[2]")).click();
		System.out.println("Create a text story clicked");
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Start typing')]"))).click().build().perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div/label/div/div/textarea")).sendKeys("This is my first text story");		
		System.out.println("Text has been given");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[contains(text(),'simple')]")).click();
		System.out.println("Text format clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[contains(text(),'clean')]")).click();
		System.out.println("Clean selected"); 
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[3]/div[2]/div[1]/div/div[3]/div[1]/div[2]/div/div[3]/div/div[3]/div[2]/div[2]/div/div/img")).click();
		System.out.println("background selected");
		driver.findElement(By.xpath("//span[contains(text(),'Share to Story')]")).click();
		System.out.println("Story has been shared");

		Thread.sleep(3000);
		driver.close();

	}

}
