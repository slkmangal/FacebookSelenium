package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Welcome2 
{

	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver=new FirefoxDriver();		
		LoginMain.loginall(driver);		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//span[contains(text(),'Welcome')]")).click();
		System.out.println("clicked on welcome");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		//Find People you may know
		WebElement findp=driver.findElement(By.cssSelector("input[placeholder='Search by name']"));
		findp.sendKeys("aayesha");
		findp.sendKeys(Keys.ENTER);
		
		//Places
		driver.findElement(By.xpath("//span[contains(text(),'Places')]")).click();
		System.out.println("Clicked on places");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.cssSelector("input[aria-label='Open now']")).click();
		System.out.println("Open Now ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.cssSelector("input[aria-label='Delivery']")).click();
		System.out.println("Delivery ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.cssSelector("input[aria-label='Takeaway']")).click();
		System.out.println("Takeaway ON");
		driver.findElement(By.xpath("//span[contains(text(),'Location')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Ashok Nagar')]")).click();
		System.out.println("Places : Location : Ashok nagar selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Status')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Temporarily closed')]")).click();
		System.out.println("Places : Status : temporarily Closed selected");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.cssSelector("input[aria-label='Visited by friends']")).click();
		System.out.println("Visited by friends ON");
		driver.findElement(By.xpath("//span[contains(text(),'Price')]")).click();
		System.out.println("Price clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//span[contains(text(),'££££')]")).click();
		System.out.println("Places : Price : ££££ selected");
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("selection reset");
		
		//Groups
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//div[9]/div[1]/a[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/span[1]/span")).click();
		System.out.println("groups Clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//div[9]/div[2]/div[1]/div/div/div/div/div/div/div[1]/div/div[1]/div/span/span")).click();
		System.out.println("Groups : City clicked");
		driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Public groups']")).click();
		System.out.println("Public groups ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='My groups']")).click();
		System.out.println("My groups ON");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("selection reset");

		//Events
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//div[10]/div[1]/a[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/span[1]/span")).click();
		System.out.println("Events clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Online events']")).click();
		System.out.println("Online events ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Paid events']")).click();
		System.out.println("Paid events ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Classes']")).click();
		System.out.println("Classes ON");
		driver.findElement(By.xpath("//div[10]/div[2]/div[4]/div/div/div/div/div/div/div[1]/div/div[1]/div/span/span")).click();
		System.out.println("Location clicked");
		driver.navigate().refresh();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[10]/div[2]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]/span[1]")).click();
		System.out.println("Dates clicked");
		driver.findElement(By.xpath("//span[contains(text(),'Next week')]")).click();
		System.out.println("Events : Dates : Next Week Selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Categories')]")).click();
		System.out.println("Events : categories clicked");
		driver.findElement(By.xpath("//span[contains(text(),'Crafts')]")).click();
		System.out.println("Events : categories : Crafts selected");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Family-friendly']")).click();
		System.out.println("Family-friendly ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.cssSelector("input[aria-label='Popular with friends']")).click();
		System.out.println("Popular with friends ON");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
		System.out.println("selection reset");	
		
		
		driver.close();

	}

}
