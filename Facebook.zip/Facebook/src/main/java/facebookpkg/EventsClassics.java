package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class EventsClassics {

	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver=new FirefoxDriver();		
		LoginMain.loginall(driver);		
		JavascriptExecutor js=(JavascriptExecutor)driver;		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//div[3]/div/div/div/div[1]/div[1]/div/div[1]/div/div/div[1]/div/div/div[1]/div[1]/ul/li[3]/div/a/div[1]/div[2]/div/div/div/div/span/span")).click();
		System.out.println("Events clicked");
		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[contains(text(),'Classics')]")).click();
		System.out.println("Events : Classics clicked");		
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[aria-label='Online']")).click();
		System.out.println("Events : Search : Online : ON");
		driver.findElement(By.cssSelector("input[aria-label='Paid']")).click();
		System.out.println("Events : Search : Paid : ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.findElement(By.xpath("//span[contains(text(),'Location')]")).click();
		System.out.println("Location clicked");
		driver.navigate().refresh();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[contains(text(),'Dates')]")).click();
		System.out.println("Dates clicked");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[2]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : today selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[3]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : tomorrow selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : this week selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[5]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : this weekend selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[6]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : Next week selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[7]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : Next weekend selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[8]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : In the Next month selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[9]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : Choose date selected");
		Thread.sleep(3000);
		WebElement ss=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div/div/div[1]/div[1]/div/div/div/div[1]/div[2]"));
		ss.click();
		ss.click();
		System.out.println("Scrolled to date view");
		Thread.sleep(3000);
		WebElement dd=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div/div/div[1]/div[1]/div/div/div/div[2]/div[5]/div[4]/div/div/span/span"));
		dd.click();
		dd.click();
		Thread.sleep(5000);
		System.out.println("Dates : choose date : 21 sep selected");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[4]/div[1]/div[2]/div/div[4]/div/div[2]/div/div[1]/div/div[1]/div/div[1]/div/div/div/span/div/div")).click();
		System.out.println("Reset done");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[contains(text(),'Dates')]")).click();
		System.out.println("Dates re-clicked");
		Thread.sleep(10000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		//driver.findElement(By.xpath("//div[contains(text(),'Categories')]")).click();
		//System.out.println("Categories clicked");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[23]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Wellness selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[11]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Games selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[2]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Art selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[3]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Causes selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Comedy selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[5]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Crafts selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[6]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Dance selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[7]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Drinks selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[8]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Film selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[9]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Fitness selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[10]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Food selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[11]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Gardening selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[12]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Health selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[13]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Home selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[14]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Literature selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[15]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Music selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[16]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Networking selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[17]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Other selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[18]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Party selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[19]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Religion selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[20]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Shopping selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[21]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Sorts selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[22]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Theatre selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[4]/div[1]/div[2]/div/div[5]/div/div[2]/div/div[1]/div/div[1]/div/div[1]/div/div/div/span/div/div")).click();
		System.out.println("Categories Reset done");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[contains(text(),'Categories')]")).click();
		System.out.println("Categories re-clicked");
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");
		Thread.sleep(5000);

		//Comedy
		driver.findElement(By.xpath("//span[contains(text(),'Comedy')]")).click();
		System.out.println("Events : Comedy clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Crafts
		driver.findElement(By.xpath("//span[contains(text(),'Crafts')]")).click();
		System.out.println("Events : Crafts clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Dance
		driver.findElement(By.xpath("//span[contains(text(),'Dance')]")).click();
		System.out.println("Events : Dance clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Drinks
		driver.findElement(By.xpath("//span[contains(text(),'Drinks')]")).click();
		System.out.println("Events : Dance clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Fitness & workouts
		driver.findElement(By.xpath("//span[contains(text(),'Fitness & workouts')]")).click();
		System.out.println("Events : Fitness & workouts clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Foods
		driver.findElement(By.xpath("//span[contains(text(),'Foods')]")).click();
		System.out.println("Events : Foods clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Games
		driver.findElement(By.xpath("//span[contains(text(),'Games')]")).click();
		System.out.println("Events : Games clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Gardening
		driver.findElement(By.xpath("//span[contains(text(),'Gardening')]")).click();
		System.out.println("Events : Gardening clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Health & Medical
		driver.findElement(By.xpath("//span[contains(text(),'Health & Medical')]")).click();
		System.out.println("Events : Health & Medical clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Healthy living and self-care
		driver.findElement(By.xpath("//span[contains(text(),'Healthy living and self-care')]")).click();
		System.out.println("Events : Healthy living and self-care clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Home and garden
		driver.findElement(By.xpath("//span[contains(text(),'Home and garden')]")).click();
		System.out.println("Events : Home and garden clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Music and audio
		driver.findElement(By.xpath("//span[contains(text(),'Music and audio')]")).click();
		System.out.println("Events : Music and audio clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Parties
		driver.findElement(By.xpath("//span[contains(text(),'Parties')]")).click();
		System.out.println("Events : Parties clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Professional networking
		driver.findElement(By.xpath("//span[contains(text(),'Professional networking')]")).click();
		System.out.println("Events : Professional networking clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Religions
		driver.findElement(By.xpath("//span[contains(text(),'Religions')]")).click();
		System.out.println("Events : Religions clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Shopping
		driver.findElement(By.xpath("//span[contains(text(),'Shopping')]")).click();
		System.out.println("Events : Shopping clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Social Issues
		driver.findElement(By.xpath("//span[contains(text(),'Social Issues')]")).click();
		System.out.println("Events : Social Issues clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Sports
		driver.findElement(By.xpath("//span[contains(text(),'Sports')]")).click();
		System.out.println("Events : Sports clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Theatre
		driver.findElement(By.xpath("//span[contains(text(),'Theatre')]")).click();
		System.out.println("Events : Theatre clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//TV and films
		driver.findElement(By.xpath("//span[contains(text(),'TV and films')]")).click();
		System.out.println("Events : TV and films clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		//Visual arts
		driver.findElement(By.xpath("//span[contains(text(),'Visual arts')]")).click();
		System.out.println("Events : Visual arts clicked");
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");

		driver.close();	

	}

}
