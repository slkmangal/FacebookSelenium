package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FindFriends {

	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();

		driver.findElement(By.name("email")).sendKeys("slkmangal@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("Automation@1234");
		driver.findElement(By.name("login")).click();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		Actions a1 = new Actions(driver);
		WebElement ff=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[1]/div/div/div[1]/div/div/div[1]/div[1]/ul/li[1]/div/a"));
		a1.moveToElement(ff).click().perform();


		//find friends Home
		driver.findElement(By.xpath("//span[contains(text(),'Home')]")).click();
		System.out.println("find fiends Home"); 

		// find fiend's fiend request		
		driver.findElement(By.xpath("//span[contains(text(),'Friend requests')]")).click();
		System.out.println("find fiends Friend Request"); 
		driver.findElement(By.xpath("//span[contains(text(),'View sent requests')]")).click();
		System.out.println("View sent request successfull");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/div[2]/div/i")).click();
		System.out.println("Alert closed");
		driver.findElement(By.cssSelector("a[href='/friends/']")).click();
		//driver.navigate().back();
		System.out.println("Back to friends page from friend request's page");

		//Find friends suggestion
		driver.findElement(By.xpath("//span[contains(text(),'Suggestions')]")).click();
		System.out.println("Clicked on suggestion link");
		driver.findElement(By.cssSelector("a[href='/friends/']")).click();
		System.out.println("Back to friends page from suggestions page");

		//Find friends All Friends
		driver.findElement(By.xpath("//span[contains(text(),'All Friends')]")).click();
		System.out.println("Clicked on All Friends link");
		Thread.sleep(3000);
		WebElement search=driver.findElement(By.cssSelector("input[placeholder='Search Friends']"));
		search.sendKeys("abcd");
		search.sendKeys(Keys.ENTER);
		System.out.println("search successfull");
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("a[href='/friends/']")).click();
		System.out.println("Back to friends page from All Friends page");


		//Find friends Birthday
		driver.findElement(By.xpath("//span[contains(text(),'Birthdays')]")).click();
		System.out.println("Birthday page opened");


		//Find friends Custom list
		driver.findElement(By.xpath("//span[contains(text(),'Custom lists')]")).click();
		System.out.println("Custom List page opened");
		driver.findElement(By.xpath("//span[contains(text(),'Create List')]")).click();
		System.out.println("Clicked on Create the list");
		WebElement crelist=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/div[4]/div/label/input"));
		crelist.sendKeys("abcd");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Cancel')]")).click();
		System.out.println("Cancel create list");
		Thread.sleep(3000);

		/*
		driver.findElement(By.xpath("//span[contains(text(),'Create List')]")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/div[4]/div/label/input")).sendKeys("MyList");		
		driver.findElement(By.xpath("//span[contains(text(),'Confirm')]")).click();
		System.out.println("List Successfully created"); 
		 */

		driver.findElement(By.cssSelector("a[href='/friends/']")).click();
		System.out.println("Back to friends page from Custom List page");


		//Find Friends Settings
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/i[1]")).click();
		WebElement s1=driver.findElement(By.cssSelector("input[role='switch']"));
		s1.click();
		System.out.println("Notifications Off");
		s1.click();
		System.out.println("Notifications ON");
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/i[1]")).click();
		System.out.println("Find Fiends Page completed");
		driver.close();




	}

}
