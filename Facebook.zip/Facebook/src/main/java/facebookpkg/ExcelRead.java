package facebookpkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead 
{
	public static void main(String[] args) throws IOException
	{
		File f=new File("E:\\shilki\\SWIGGY\\Data\\Crediantials.xlsx");
		FileInputStream fis=new FileInputStream(f);

		XSSFWorkbook w=new XSSFWorkbook(fis);
		XSSFSheet sh=w.getSheet("Registration");

		for(int i=1; i<10; i++)
		{
			String phone= sh.getRow(i).getCell(0).toString();
			String name= sh.getRow(i).getCell(1).toString();
			String email= sh.getRow(i).getCell(2).toString();
			String pw= sh.getRow(i).getCell(3).toString();
			System.out.println(phone+ " , " +name+ " , " +email+ " , " +pw);
			
			
			
		}
		
		
	System.out.println("Completed");
	
	

	

	}

}
