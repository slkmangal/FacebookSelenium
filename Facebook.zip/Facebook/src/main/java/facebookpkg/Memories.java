package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Memories 
{
	public static void main(String[] args) throws InterruptedException
	{
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		LoginMain.loginall(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.findElement(By.xpath("//span[contains(text(),'Memories')]")).click();
		System.out.println("Memories clicked");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),'Memories home')]")).click();
		System.out.println("Memories : Memories Home clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Notifications')]")).click();
		System.out.println("Memories : Notifications clicked");
		Thread.sleep(3000);
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(By.cssSelector("div[aria-label='Highlights']"))).click().build().perform();
		System.out.println("Memories : Notifications : Highlights selected");
		Thread.sleep(3000);
		a.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Hide people')]"))).click().build().perform();
		System.out.println("Memories : Hide People clicked");
		Thread.sleep(3000);
		a.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Hide dates')]"))).click().build().perform();
		System.out.println("Memories : Hide dates clicked");
		Thread.sleep(3000);
		
		driver.close();
		
	}
}
