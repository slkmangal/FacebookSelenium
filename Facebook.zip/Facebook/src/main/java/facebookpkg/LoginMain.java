package facebookpkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import repos.LoginObs;

public class LoginMain 
{
	public static void loginall(WebDriver driver) throws InterruptedException
	{
		driver.get("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();

		LoginObs.un(driver).sendKeys("slkmangal@gmail.com");
		LoginObs.pw(driver).sendKeys("Automation@1234");
		LoginObs.submit(driver).click();
		
	}

}
