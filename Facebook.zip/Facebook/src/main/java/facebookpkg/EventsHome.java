package facebookpkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import repos.EventsHomeRepo;

public class EventsHome {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		LoginMain.loginall(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//div[3]/div/div/div/div[1]/div[1]/div/div[1]/div/div/div[1]/div/div/div[1]/div[1]/ul/li[3]/div/a/div[1]/div[2]/div/div/div/div/span/span")).click();
		System.out.println("Events clicked");
		Thread.sleep(3000);


		//Home 
		driver.findElement(By.xpath("//div[3]/div[1]/div[2]/div[1]/a[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/span[1]")).click(); 
		System.out.println("Home clicked"); 
		//Your Events
		driver.findElement(By.xpath("//span[contains(text(),'Your events')]")).click(); 
		System.out.println("Events : Your events selected");
		driver.findElement(By.xpath("//span[contains(text(),'Going')]")).click();
		System.out.println("Events : Your events : Going selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Invitations')]")).click(); 
		System.out.println("Events : Your events : Invitations selected");
		driver.findElement(By.xpath("//span[contains(text(),'Interested')]")).click();
		System.out.println("Events : Your events : Interested selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Hosting')]")).click();
		System.out.println("Events : Your events : Hosting selected");
		driver.findElement(By.xpath("//span[contains(text(),'Past events')]")).click(); 
		System.out.println("Events : Your events : Past events selected");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		Thread.sleep(5000); 
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div[2]/a/div[1]/div[2]/div[1]/div/div/div/span")).click(); 
		System.out.println("Clicked Reset"); 
		//Birthdays
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div[4]/a/div[1]/div[2]/div/div/div/div/span")).click(); 
		System.out.println("Birthdays clicked"); 
		//Notifications
		Thread.sleep(5000); 
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[3]/div[1]/div[2]/div[5]/a/div[1]/div[2]/div/div/div/div/span")).click(); 
		Thread.sleep(5000);
		System.out.println("Notifications clicked");
		// Search
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));		
		Actions a=new Actions(driver);
		a.moveToElement(EventsHomeRepo.search(driver)).click().build().perform();
		a.sendKeys(EventsHomeRepo.search(driver), "Loard Ram").build().perform();
		a.sendKeys(EventsHomeRepo.search(driver), Keys.ENTER).build().perform();
		Thread.sleep(3000);
		System.out.println("Search result is here");
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[aria-label='Online']")).click();
		System.out.println("Events : Search : Online : ON");
		driver.findElement(By.cssSelector("input[aria-label='Paid']")).click();
		System.out.println("Events : Search : Paid : ON");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.findElement(By.xpath("//span[contains(text(),'Location')]")).click();
		System.out.println("Location clicked");
		driver.navigate().refresh();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[contains(text(),'Dates')]")).click();
		System.out.println("Dates clicked");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[2]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : today selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[3]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : tomorrow selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : this week selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[5]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : this weekend selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[6]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : Next week selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[7]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : Next weekend selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[8]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : In the Next month selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[4]/div/div[2]/div/div[9]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Dates : Choose date selected");
		Thread.sleep(3000);
		WebElement ss=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div/div/div[1]/div[1]/div/div/div/div[1]/div[2]"));
		ss.click();
		ss.click();
		System.out.println("Scrolled to date view");
		Thread.sleep(3000);
		WebElement dd=driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div/div/div[1]/div[1]/div/div/div/div[2]/div[5]/div[4]/div/div/span/span"));
		dd.click();
		dd.click();
		Thread.sleep(5000);
		System.out.println("Dates : choose date : 21 sep selected");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[4]/div[1]/div[2]/div/div[4]/div/div[2]/div/div[1]/div/div[1]/div/div[1]/div/div/div/span/div/div")).click();
		System.out.println("Reset done");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[contains(text(),'Dates')]")).click();
		System.out.println("Dates re-clicked");
		
		driver.findElement(By.xpath("//div[contains(text(),'Categories')]")).click();
		System.out.println("Categories clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[23]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Wellness selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[11]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Games selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[2]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Art selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[3]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Causes selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Comedy selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[5]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Crafts selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[6]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Dance selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[7]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Drinks selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[8]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Film selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[9]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Fitness selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[10]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Food selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[11]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Gardening selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[12]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Health selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[13]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Home selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[14]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Literature selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[15]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Music selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[16]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Networking selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[17]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Other selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[18]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Party selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[19]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Religion selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[20]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Shopping selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[21]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Sorts selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[5]/div/div[2]/div/div[22]/div/div/div[1]/div/div[2]/div/div/div")).click();
		System.out.println("Categories : Theatre selected");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[1]/div/div[4]/div[1]/div[2]/div/div[5]/div/div[2]/div/div[1]/div/div[1]/div/div[1]/div/div/div/span/div/div")).click();
		System.out.println("Categories Reset done");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[contains(text(),'Categories')]")).click();
		System.out.println("Categories re-clicked");
		driver.navigate().to("https://www.facebook.com/events?source=46&action_history=null");
		Thread.sleep(5000);
		
		//Create new event
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.findElement(By.xpath("//span[contains(text(),'Create New Event')]")).click(); 
		System.out.println("Create new event clicked"); 
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[2]/div[1]/div[1]/span/div/i")).click();
		System.out.println("Create new event closed");
		
		


		driver.close();

	}

}
