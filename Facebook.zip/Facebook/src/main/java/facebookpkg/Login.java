package facebookpkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import repos.LoginObs;

public class Login
{

	public static void main(String[] args) throws InterruptedException, IOException
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();

		File f=new File("data/Crediantials.xlsx");
		FileInputStream fis=new FileInputStream(f);

		XSSFWorkbook w=new XSSFWorkbook(fis);
		XSSFSheet sh=w.getSheet("Login");


		for(int i=1; i<4; i++)
		{
			LoginObs.un(driver).clear();
			LoginObs.pw(driver).clear();
			
			String emilmob= sh.getRow(i).getCell(0).toString();
			String pw= sh.getRow(i).getCell(1).toString();
			System.out.println(emilmob+ " , " +pw);

			LoginObs.un(driver).sendKeys(emilmob);

			LoginObs.pw(driver).sendKeys(pw);
			
			LoginObs.submit(driver).click();
			Thread.sleep(5000);
			//System.out.println(driver.getCurrentUrl());
			
			if(driver.getCurrentUrl().equalsIgnoreCase("https://www.facebook.com/?sk=welcome"))
			{
				System.out.println("Logged in successfully");
			}

			else
			{

				System.out.println("Invalid username/password");
				try
				{
					LoginObs.contBtn(driver).click();
				}
				
				catch(Exception e)
				{
					
				}
				LoginObs.un(driver).clear();
				LoginObs.pw(driver).clear();
				driver.navigate().refresh();

			}
		}

		System.out.println("Login Completed");
		driver.quit();

	}

}
